//
//  main.m
//  TrigSolv
//
//  Created by Justin Buchanan on 11/17/08.
//  Copyright JustBuchanan Software 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{	
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, nil);
	[pool release];
	return retVal;
}
