//
//  RectangleController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/24/08.
//  Copyright 2008 JustBuchanan Enterprises. All rights reserved.
//

#import "ShapeController.h"
#import "RectangleView.h"


@interface RectangleController : ShapeController


@end
