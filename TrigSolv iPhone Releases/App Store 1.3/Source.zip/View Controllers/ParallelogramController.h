//
//  ParallelogramController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/24/08.
//  Copyright 2008 JustBuchanan Enterprises. All rights reserved.
//

#import "ShapeController.h"
#import "ParallelogramView.h"


@interface ParallelogramController : ShapeController
{

}

@end
