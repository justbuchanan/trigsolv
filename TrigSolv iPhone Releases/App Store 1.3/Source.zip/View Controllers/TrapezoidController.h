//
//  TrapezoidController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/24/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//


#import "ShapeController.h"
#import "TrapezoidView.h"


@interface TrapezoidController : ShapeController
{

}

@end
