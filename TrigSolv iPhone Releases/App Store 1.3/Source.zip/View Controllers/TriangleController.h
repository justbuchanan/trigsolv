//
//  TriangleController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/24/08.
//  Copyright 2008 JustBuchanan Enterprises. All rights reserved.
//


#import "ShapeController.h"
#import "TriangleView.h"


@interface TriangleController : ShapeController

@end
