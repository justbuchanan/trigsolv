//
//  CircleController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/23/08.
//  Copyright 2008 JustBuchanan Enterprises. All rights reserved.
//

#import "ShapeController.h"


@interface CircleController : ShapeController

@end
