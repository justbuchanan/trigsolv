//
//  EllipseController.h
//  Shape Master
//
//  Created by Justin Buchanan on 9/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "ShapeController.h"
#import "EllipseView.h"


@interface EllipseController : ShapeController

@end
